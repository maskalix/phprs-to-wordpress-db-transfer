<?php
/*
Plugin Name: phpRS Galerie
Plugin URI: https://github.com/maskalix/phprs-to-wordpress-db-transfer/
Description: Plugin fungující jako phpRS bridge pro galerie; shortcode: [custom_gallery]
Version: 1.0.0
Author: Martin Skalicky
Author URI: https://skali.eu
*/

// Enqueue plugin styles
function custom_gallery_enqueue_styles() {
    wp_enqueue_style('custom-gallery', plugins_url('custom-gallery.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'custom_gallery_enqueue_styles');

// Funkce pro získání úplné URL adresy obrázku
function custom_get_full_image_url($file_path) {
    $image_path = str_replace('gallery/', '', $file_path); // Odstranit "gallery/" z cesty k obrázku
    return site_url() . '/wp-content/gallery/' . $image_path; // Získat úplné URL adresu obrázku
}

// Shortcode pro zobrazení seznamu galerií
function custom_gallery_shortcode($atts) {
    if (isset($_GET['gallery_id'])) {
        $gallery_id = absint($_GET['gallery_id']);
        return custom_display_gallery($gallery_id);
    } else {
        // Kód pro dotaz na databázi a získání dat galerií seřazených od nejnovější po nejstarší
        global $wpdb;
        $galleries = $wpdb->get_results("SELECT gallery_id, gallery_title, gallery_description, gallery_zalozeni FROM {$wpdb->prefix}gallery ORDER BY gallery_zalozeni DESC");
        $output = '<table class="custom-gallery-list">';
        $output .= '<tr><th>Náhled</th><th>Datum vytvoření</th><th>Název</th><th>Popis</th><th>Otevřít galerii</th></tr>';
        foreach ($galleries as $gallery) {
            $thumbnail = $wpdb->get_var("SELECT media_file FROM {$wpdb->prefix}media WHERE media_gallery_id = $gallery->gallery_id ORDER BY media_id DESC LIMIT 1");
            $thumbnail_url = $thumbnail ? custom_get_full_image_url($thumbnail) : '';
            
            // Skip the gallery if the thumbnail doesn't exist
            if (empty($thumbnail_url)) {
                continue;
            }

            $output .= '<tr>';
            $output .= '<td><img src="' . esc_url($thumbnail_url) . '" alt="' . esc_attr($gallery->gallery_title) . '"></td>';
            $output .= '<td>' . date('d. m. Y', strtotime($gallery->gallery_zalozeni)) . '</td>';
            $output .= '<td>' . esc_html($gallery->gallery_title) . '</td>';
            $output .= '<td>' . esc_html($gallery->gallery_description) . '</td>';
            $output .= '<td><a href="' . esc_url(add_query_arg('gallery_id', $gallery->gallery_id)) . '">Otevřít album</a></td>';
            $output .= '</tr>';
        }
        $output .= '</table>';
        return $output;
    }
}
add_shortcode('custom_gallery', 'custom_gallery_shortcode');

// Funkce pro zobrazení vybrané galerie
function custom_display_gallery($gallery_id) {
    global $wpdb;
    $gallery_id = absint($gallery_id);

    $gallery_info = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}gallery WHERE gallery_id = $gallery_id");
    $images = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}media WHERE media_gallery_id = $gallery_id");

    // Check if the gallery has no photos
    if (empty($images)) {
        // Výstup s chybovou zprávou, pokud nejsou pro galerii k dispozici žádné obrázky
        return '<div class="gallery-error">Chyba: Pro vybranou galerii nebyly nalezeny žádné obrázky.</div>';
    }

    $output = '<div class="custom-gallery-single">';
    $output .= '<div class="gallery-info">';
    $output .= '<div class="gallery-date">' . date('d. F Y', strtotime($gallery_info->gallery_zalozeni)) . '</div>';
    $output .= '<div class="gallery-title">' . esc_html($gallery_info->gallery_title) . '</div>';
    $output .= '<div class="gallery-description">' . esc_html($gallery_info->gallery_description) . '</div>';
    $output .= '</div>';
    $output .= '<a href="' . esc_url(remove_query_arg('gallery_id')) . '" class="back-to-list">Zpět na seznam galerií</a>';
    $output .= '<div class="gallery-images">';
    foreach ($images as $image) {
        $image_url = custom_get_full_image_url($image->media_file);
        $output .= '<a href="' . esc_url($image_url) . '" target="_blank">';
        $output .= '<img src="' . esc_url($image_url) . '" alt="' . esc_attr($image->media_caption) . '">';
        $output .= '</a>';
        $output .= '<div class="image-description">' . esc_html($image->media_description) . '</div>';
    }
    $output .= '</div>';

    $output .= '</div>';

    return $output;
}
