<?php
/*
Plugin Name: Custom Gallery
Description: A custom gallery plugin for WordPress.
Version: 1.0
Author: Your Name
*/

// Enqueue plugin styles
function custom_gallery_enqueue_styles() {
    wp_enqueue_style('custom-gallery', plugins_url('css/custom-gallery.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'custom_gallery_enqueue_styles');

// Shortcode to display the gallery list
function custom_gallery_shortcode($atts) {
    if (isset($_GET['gallery_id'])) {
        $gallery_id = absint($_GET['gallery_id']);
        return custom_display_gallery($gallery_id);
    } else {
        // Code to query the database and retrieve gallery data
        global $wpdb;
        $galleries = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}wp_gallery ORDER BY gallery_zalozeni DESC");

        // Code to generate the HTML output for the gallery list
        $output = '<div class="custom-gallery-list">';
        foreach ($galleries as $gallery) {
            $thumbnail = $wpdb->get_var("SELECT media_file FROM {$wpdb->prefix}wp_media WHERE media_gallery_id = $gallery->gallery_id ORDER BY media_id ASC LIMIT 1");

            $output .= '<a href="' . esc_url(add_query_arg('gallery_id', $gallery->gallery_id)) . '">';
            $output .= '<img src="' . esc_url($thumbnail) . '" alt="' . esc_attr($gallery->gallery_title) . '">';
            $output .= '<div class="gallery-title">' . esc_html($gallery->gallery_title) . '</div>';
            $output .= '</a>';
        }
        $output .= '</div>';

        return $output;
    }
}
add_shortcode('custom_gallery', 'custom_gallery_shortcode');

// Function to display the selected gallery
function custom_display_gallery($gallery_id) {
    global $wpdb;
    $gallery_id = absint($gallery_id);
    $images = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}wp_media WHERE media_gallery_id = $gallery_id");

    $output = '<div class="custom-gallery-single">';
    foreach ($images as $image) {
        $output .= '<div class="gallery-item">';
        $output .= '<img src="' . esc_url($image->media_file) . '" alt="' . esc_attr($image->media_caption) . '">';
        $output .= '<div class="caption">' . esc_html($image->media_caption) . '</div>';
        $output .= '<div class="description">' . esc_html($image->media_description) . '</div>';
        $output .= '</div>';
    }
    $output .= '</div>';

    return $output;
}
