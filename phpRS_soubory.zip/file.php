<?php
/*
Plugin Name: phpRS Soubory
Plugin URI: https://github.com/maskalix/phprs-to-wordpress-db-transfer/
Description: Plugin fungující jako phpRS bridge pro soubory vložené do stránky jako "file.php?id="
Version: 1.0.0
Author: Martin Skalicky
Author URI: https://skali.eu
*/

// This function will handle the file display and download
function custom_file_viewer() {
    global $wpdb;

    // Check if the 'id' parameter is set in the URL
    if (isset($_GET['id'])) {
        $nazev = sanitize_text_field($_GET['id']);

        // Retrieve file information from the wp_files table
        $file_info = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT nazev, koncovka, mime FROM {$wpdb->prefix}files WHERE nazev = %s",
                $nazev
            )
        );

        // Check if the file exists in the wp_files table
        if ($file_info) {
            $file_path = 'wp-content/storage/' . $file_info->nazev . $file_info->koncovka;

            // Check if the file physically exists on the server
            if (file_exists($file_path)) {
                $file_name = $file_info->nazev . $file_info->koncovka;
                $file_mime = $file_info->mime;

                
                // Display the image if the mime type starts with 'image/'
                if (strpos($file_mime, 'image/') === 0) {
                    header('Content-Type: ' . $file_mime);
                    readfile($file_path);
                    exit;
                } else {
                    // Download the file for other mime types
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . $file_name . '"');
                    header('Content-Transfer-Encoding: binary');
                    header('Content-Length: ' . filesize($file_path));
                    readfile($file_path);
                    exit;
                }
            } else {
                echo '<p style="text-align:center; color:red"><br>File not found on the server.<br></p>';
            }
        } else {}
    } else {}
}

// Hook the custom function to a WordPress action
add_action('init', 'custom_file_viewer');